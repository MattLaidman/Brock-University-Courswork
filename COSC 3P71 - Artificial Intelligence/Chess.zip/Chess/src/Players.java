enum Players {

    Human,
    Computer

}
