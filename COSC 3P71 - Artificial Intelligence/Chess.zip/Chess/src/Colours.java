enum Colours {

    White,
    Black

}
