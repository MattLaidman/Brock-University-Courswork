enum Pieces {

    Rook,
    Knight,
    Bishop,
    Queen,
    King,
    Pawn

}
