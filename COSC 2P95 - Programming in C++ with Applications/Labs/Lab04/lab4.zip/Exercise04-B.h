#include <iostream>
#include <iomanip>
#include <fstream>
#include<sstream>
#include <cmath>

int getNumGraduations();
int getNumFrames();
double getFunctionValue(double, double, double);
void makePGM(int, int, double*);