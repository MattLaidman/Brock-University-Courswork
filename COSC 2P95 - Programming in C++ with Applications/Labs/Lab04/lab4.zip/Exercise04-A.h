#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>

int getNumGraduations();
double getFunctionValue(double, double, double);
void makePGM(int, double*);