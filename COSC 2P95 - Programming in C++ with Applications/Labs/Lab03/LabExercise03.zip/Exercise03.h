#include <iostream>
#include <cmath>
#include <string>

double funcOne (double, double);
double funcTwo (double, double);
double funcThree (double, double);
double funcFour (double, double);

void printBitmap (int, double*);
void printValues (int, double*);

int getChoice ( );
int getNumGraduations ( );
int getOutputType ( );