//This header file contains the forward declarations
#define random 4 //again, I really wouldn't advise defining constants this way
int max(int a,int b);
int min(int,int); //You CAN do this, but it's better to have descriptive parameter names
