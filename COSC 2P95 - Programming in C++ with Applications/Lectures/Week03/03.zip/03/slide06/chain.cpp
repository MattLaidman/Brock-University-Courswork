#include <iostream>
using namespace std;
// This example works just fine. No warnings, no concerns.
// However, try swapping the two procedures, and see what happens.

void exclamation() {
	cout<<"Woo!"<<endl;
}

void proclamation() {
	cout<<"Outlaw Country!"<<endl;
	exclamation();
}

int main() {
	proclamation();
}
