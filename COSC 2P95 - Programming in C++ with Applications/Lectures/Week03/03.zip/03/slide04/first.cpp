#include <iostream>
using namespace std;

void wokka() {
	int dealie=8;
	cout<<"Grobble grobble grobble!"<<endl;
}

int main() {
	wokka();
}
