#include <iostream>
using namespace std;
#define PI 3
const double totesrandom=4;
constexpr float dealie=9;
constexpr float max(float a, float b) {return b>a?b:a;}

int main() {
	cout<<max(5,3)<<endl;
}
