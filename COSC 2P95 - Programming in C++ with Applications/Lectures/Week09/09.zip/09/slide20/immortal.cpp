#include <signal.h>
#include <iostream>
#include <unistd.h>

//This one provides handlers for both SIGINT (ctrl+c) and SIGTERM (default 'kill' signal)
//So... how can we stop it?

void stubborn(int sig) {
	std::cout<<"\nYeah... no. I think I'll be continuing."<<std::endl;
}

int main(int argc, char *argv[]) {
	if (signal(SIGTERM,stubborn)==SIG_ERR) {
		std::cout<<"Oh noes! Something didn't work!"<<std::endl;
		return 1;
	}
	if (signal(SIGINT,stubborn)==SIG_ERR) {
		std::cout<<"Oh noes! Something didn't work!"<<std::endl;
		return 1;
	}
	while (true) {
		std::cout<<"Llama llama! Llama llama llama!"<<std::endl;
		usleep(500000);
		std::cout<<"\tLlama llama! Llama llama llama!"<<std::endl;
		usleep(500000);
	}
}