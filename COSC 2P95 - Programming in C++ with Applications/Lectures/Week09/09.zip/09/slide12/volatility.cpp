#include <iostream>
#include <pthread.h>
#include <unistd.h>

volatile int stop=0;//This is volatile, to ensure that we're using the 'current' version

void *proccy(void *argument) {
	while (!stop) {
		std::cout<<"\tI'm a thread!"<<std::endl;
		usleep(500000);
	}
	pthread_exit(NULL);
}

int main() {
	pthread_t ct;//our child thread
	
	pthread_create(&ct, NULL, proccy, NULL);
	sleep(5);
	stop=1;
	//Note: I also could have used pthread_cancel to stop the child
}

