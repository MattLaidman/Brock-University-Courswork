#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <iostream>

void impatientparent() {
	std::cout<<"Can I start yet?"<<std::endl;
	wait(0); //note: being super-lazy with wait here. Definitely read the manual for wait and waitpid
	std::cout<<"Finally! Took ya long enough!"<<std::endl;
}

void lazychild() {
	sleep(3);
	std::cout<<"\t\t*yawn*... guess I should get started... eventually..."<<std::endl;
	sleep(2);
	std::cout<<"\t\t...there... that good?"<<std::endl;
	sleep(1);
	std::cout<<"\t\tYup! Done!"<<std::endl;
}

int main() {
	std::cout<<"Starting."<<std::endl;
	if (fork()) { //non-zero returns means this is the parent/original
		impatientparent();
	}
	else {
		lazychild();
	}
	std::cout<<"Done?"<<std::endl;
}
