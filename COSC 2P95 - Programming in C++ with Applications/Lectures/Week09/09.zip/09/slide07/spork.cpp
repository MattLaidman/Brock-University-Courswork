#include <unistd.h>
#include <iostream>

void gripe() {
	while (1) {
		std::cout<<"In my day..."<<std::endl;
		sleep(1);
		std::cout<<"\t...six miles through the snow; uphill both ways!"<<std::endl;
		sleep(1);
	}
}

void complain() {
	while (1) {
		std::cout<<"\t\t\tNuh uh! I totally know better!"<<std::endl;
		sleep(1);
		std::cout<<"\t\t\t\tYou're just jealous!"<<std::endl;
		sleep(1);
	}
}

int main() {
	std::cout<<"Starting."<<std::endl;
	if (fork()) { //non-zero returns means this is the parent/original
		gripe();
	}
	else {
		complain();
	}
	std::cout<<"Done?"<<std::endl;
}
