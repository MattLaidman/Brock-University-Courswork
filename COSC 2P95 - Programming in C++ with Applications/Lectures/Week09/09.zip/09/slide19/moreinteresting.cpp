#include <signal.h>
#include <unistd.h>
#include <iostream>

//Use another program (e.g. kill) to send this process a signal
//(You'll usually need the PID of the process to send a signal. I'm partial to pidof)

void handler(int sig) {
	std::cout<<"I've started hearing voices."<<std::endl;
	std::cout<<"Is that a bad thing?"<<std::endl;
	std::cout<<"It's probably fine."<<std::endl;
}

int main(int argc, char *argv[]) {
	int c;
	signal(SIGUSR1,handler);
	signal(SIGUSR2,SIG_IGN); //try commenting this out
	while (1) {
		std::cout<<"..."<<std::endl;
		usleep(500000);
		std::cout<<"\t..."<<std::endl;
		usleep(500000);
		std::cout<<"\t\t..."<<std::endl;
		usleep(500000);
		std::cout<<"\t\t\t..."<<std::endl;
		usleep(500000);
	}
}