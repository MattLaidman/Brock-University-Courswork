#include <unistd.h>
#include <signal.h>
#include <iostream>

//This one uses one of the two user signals: SIGUSR1.
//These can be triggered from outside. However, you can also raise a signal
//from inside your program, if it's useful

//That said, this particular example is ridiculous
void handler(int sig) {
	std::cout<<"Nooooooooooooooooo!"<<std::endl;
	std::cout<<"no."<<std::endl;
}

int main(int argc, char *argv[]) {
	int c;
	signal(SIGUSR1,handler);
	do {
		std::cout<<">0 to double, 0 to quit: ";
		std::cin>>c;
		if (c<0) raise(SIGUSR1);
		else std::cout<<"\t"<<(c*2)<<std::endl;
	} while (c!=0);
}