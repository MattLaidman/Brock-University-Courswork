#include <iostream>
#include <unistd.h>
#include <signal.h>
#include <cstdlib>

void handler(int sig) {
	std::cout<<std::endl<<"Oh. I hadn't realized you didn't want that stuck in your head."<<std::endl;
	std::cout<<"I'll stop now."<<std::endl;
	std::cout<<"Because it surely isn't already stuck in there."<<std::endl;
	exit(0); //<- important! be careful! certainly don't comment this out! (that said, 'exit' is REALLY inelegant!)
}

int main(int argc, char *argv[]) {
	//Let's try to assign the signal handler for the Interrupt Signal
	if (signal(SIGINT,handler)==SIG_ERR) {
		std::cout<<"Oh noes! Something didn't work!"<<std::endl;
		return 1;
	}
	while (true) {
		std::cout<<"This is the song that never ends..."<<std::endl;
		usleep(500000);
		std::cout<<"\tyes, it goes on and on my friend..."<<std::endl;
		usleep(500000);
		std::cout<<"\t\tsome people started singing it not knowing what it was..."<<std::endl;
		usleep(500000);
		std::cout<<"\t\t\tand they'll continue singing it forever just because..."<<std::endl;
		usleep(500000);
	}
}