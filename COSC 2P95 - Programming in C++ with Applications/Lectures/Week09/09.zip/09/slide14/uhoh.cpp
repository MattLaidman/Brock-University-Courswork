#include <iostream>
#include <pthread.h>
#include <unistd.h>

volatile int ctr=0;

void *child(void *argument) {
	while (1) {
		ctr++;
		usleep(1000);
		ctr--;
		usleep(1000);
	}
}

int main() {
	pthread_t cA,cB;//our child threads
	
	pthread_create(&cA, NULL, child, NULL);
	pthread_create(&cB, NULL, child, NULL);
	while (1) {
		std::cout<<ctr<<std::endl;
		usleep(100000);
	}
}

