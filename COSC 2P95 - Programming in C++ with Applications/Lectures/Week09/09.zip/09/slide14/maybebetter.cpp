#include <iostream>
#include <pthread.h>
#include <unistd.h>

volatile int ctr=0;
pthread_mutex_t lock;
//Note that you can have multiple mutexes, if you wish to control access to different resources separately
//Be extra-careful about deadlocks if you do, though!

void *child(void *argument) {
	while (1) {
		pthread_mutex_lock(&lock);
		ctr++;
		pthread_mutex_unlock(&lock); //comment these two out to completely fix this
		usleep(1000);
		pthread_mutex_lock(&lock); //comment these two out to completely fix this
		ctr--;
		pthread_mutex_unlock(&lock);
		usleep(1000);
	}
}

int main() {
	pthread_t cA,cB;//our child threads
	
	pthread_mutex_init(&lock,NULL);
	
	pthread_create(&cA, NULL, child, NULL);
	pthread_create(&cB, NULL, child, NULL);
	while (1) {
		std::cout<<ctr<<std::endl;
		usleep(10000);
	}
	pthread_mutex_destroy(&lock);
	return 0;
}

