#include <signal.h>
#include <iostream>
#include <unistd.h>

//A SIGWINCH is a 'window-change' signal
//It's particularly useful for terminal programs that are trying to maximize use of the terminal size

static int ctr;

void wayneandgarth(int sig) {
	std::cout<<(ctr==0?"":ctr==1?" ":"  ");
	ctr=(ctr+1)%3;
	std::cout<<"whoooooaaaaaaaa!"<<std::endl;
}

int main(int argc, char *argv[]) {
	if (signal(SIGWINCH,wayneandgarth)==SIG_ERR) {
		std::cout<<"Not a fan, I guess..."<<std::endl;
	}
	while (1) {
		sleep(1);
	}
}