#include <signal.h>
#include <iostream>
#include <unistd.h>

//Alarms can be an interesting way to schedule behaviours for a later time
//Of course, an alarm handler can schedule another alarm, if desired

//You should be looking up all of the signals, but you can find more about alarm signals here:
//https://www.gnu.org/software/libc/manual/html_node/Alarm-Signals.html

void ringadingding(int sig) {
	std::cout<<"\t>yawn!<"<<std::endl;
	std::cout<<"\t*hits snooze*"<<std::endl;
}

int main(int argc, char *argv[]) {
	int i;
	if (signal(SIGALRM,ringadingding)==SIG_ERR) {
		std::cout<<"Nah. No time for sleep anyway."<<std::endl;
	}
	
	std::cout<<"Setting alarm for r seconds..."<<std::endl;
	alarm(4);
	
	std::cout<<"Activate slumber protocols."<<std::endl;
	for (i=0;i<50000;i++) {
		usleep(100);
	}
	std::cout<<"Slumber protocols complete."<<std::endl;
}