#include <iostream>

int main(int argc, char *argv[]) {
	std::cout<<"Hello class!"<<std::endl;
}
