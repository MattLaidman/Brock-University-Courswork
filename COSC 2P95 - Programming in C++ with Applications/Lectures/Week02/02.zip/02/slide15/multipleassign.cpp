#include <iostream>
#include <string>

int main() {
	int k,m;
	double d,e;
	k=d=m=e=3.6;
	std::cout<<k<<'\t'<<d<<'\t'<<m<<'\t'<<e<<std::endl;
}
