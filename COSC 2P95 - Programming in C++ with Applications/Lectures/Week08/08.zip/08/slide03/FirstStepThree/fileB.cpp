static int bebe() {
	return 73;
}
