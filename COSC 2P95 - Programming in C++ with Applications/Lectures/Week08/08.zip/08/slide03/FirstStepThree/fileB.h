static int bebe(); //If fileB were to be used by another file at all, should probably remove this line entirely
