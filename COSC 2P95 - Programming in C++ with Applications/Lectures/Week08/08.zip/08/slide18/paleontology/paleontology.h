//This is a proper Include Guard
#ifndef PALEONTOLOGY_H
#define PALEONTOLOGY_H
/*Paleontology library
 *Because dinosaurs are spiffy!
 */

namespace paleontology {
	class Dinosaur {
	public:
		void speakTheTruth();
		void confess();
	};
}

#endif
