#include <iostream>
#include "paleontology.h"

namespace paleontology {
	void Dinosaur::speakTheTruth() {
		std::cout<<"Please wear appopriate footwear when trying to outrun me."<<std::endl;
	}
	
	void Dinosaur::confess() {
		std::cout<<"I wish I were a Blood Dragon."<<std::endl;
	}
}
