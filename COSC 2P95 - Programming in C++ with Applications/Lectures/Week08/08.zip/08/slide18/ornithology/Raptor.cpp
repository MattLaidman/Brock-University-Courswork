#include <iostream>
#include "Raptor.h"

namespace ornithology {
	void Raptor::hunt() {
		std::cout<<"Ka... me... ha... meee..... WHAT'S THAT BEHIND YOU?!? *stab stab stab*"<<std::endl;
	}
}
