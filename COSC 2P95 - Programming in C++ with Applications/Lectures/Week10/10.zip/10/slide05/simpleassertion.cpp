#include <iostream>
#include <cassert>
int main() {
	int value;
	
	std::cout<<"Pick a number from 1 to 5: ";
	std::cin>>value;
	assert(value>=1&&value<=5);
	std::cout<<"Neat!"<<std::endl;
}
