#include <iostream>
#include <string>
#include <fstream>
//Suppose the user is supposed to enter a file name to read. What could go wrong?
//	*The user might not enter anything at all
//	*The program might not be able to access that file
//	*The file might have unexpected input (e.g. strings instead of numbers)
//	*The file might have otherwise invalid input
//	*The input could be coming from a file (that's hit EOF), or similary the user could have pressed ctrl+d
//How many of these could be handled within the same context?

//The sample problem here is ludicrously simple: it wants to read two numbers from a text file to divide

const int USER_GONE=777;
const int BAD_DATA=666;

//Retrieve filename
void getFName(char fname[80]) {
	std::cout<<"Name of file to open: ";
	std::cin>>fname;
	if (std::cin.eof()) throw USER_GONE;
}

//Retrieve values, without concern for usefulness
void readValues(double &num, double &den) {
	char fname[80];
	std::ifstream fin;
	bool done=false;
	do {
		do {
			getFName(fname);
			fin.open(fname);
		} while (!fin); //Notice that not all error-checking requires exceptions!
		try {
			fin>>num;
			if (fin.fail()) throw BAD_DATA;
			
			fin>>den;
			if (fin.fail()) throw BAD_DATA;
			if (den==0) throw den; //Note: this one isn't an int
			fin.close();
			done=true;
		}
		catch (int ie) {
			if (ie==USER_GONE) //We can't handle this here
				throw USER_GONE; //So we need to re-propagate it up/out
			std::cout<<"I think that was the wrong file."<<std::endl;
			fin.close(); //Probably good to close this here
		}
	} while (!done);
}

//Actually perform calculation
void doMath() {
	double num,den;
	bool finished=false;
	do {
		try {
			readValues(num,den);
			std::cout<<num<<"/"<<den<<"="<<(num/den)<<std::endl;
			finished=true;
		}
		catch (double d) {
			std::cout<<"Seriously? "<<d<<"?"<<std::endl;
		}
	} while (!finished);
}

//Request calculation
int main() {
	doMath();
}
