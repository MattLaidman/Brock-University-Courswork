#include <iostream>
//Try not to think of exceptions as being synonymous with errors
//There's certainly a lot of overlap, but there's still a difference

const int YOUNEVERLISTEN=1;
int main() {
	int value;
	try { //My "people never follow instructions" senses are tingling!
		std::cout<<"Enter a number from 1 to 5: "<<std::endl;
		std::cin>>value;
		if (value<1 || value>5) throw YOUNEVERLISTEN;
		std::cout<<"Hey! Yes! Good answer! "<<value<<"!"<<std::endl;
	}
	//catch (int){ //If we don't care about identifying the exception (other than being an 'int'), use this
	catch (int e){ //If we might want to know the precise value, use this
		std::cout<<"Not the best reading skills, eh?"<<std::endl;
	}
	std::cout<<"We're done! (either way!)"<<std::endl;
}
