#include <iostream>
//Try not to think of exceptions as being synonymous with errors
//There's certainly a lot of overlap, but there's still a difference

const int YOUNEVERLISTEN=1;
int main() {
	double num,den;
	bool valid=false;
	do {
		try { //My "people never follow instructions" senses are tingling!
			std::cout<<"Let's try dividing! Give me a numerator: ";
			std::cin>>num;
			if (std::cin.fail()) throw YOUNEVERLISTEN;
			std::cout<<"Great! Now, how about a denominator? ";
			std::cin>>den;
			if (std::cin.fail()) throw YOUNEVERLISTEN;
			if (den==0) throw den;
			valid=true;
		}
		catch (int){ //Being an 'int' is honestly adequate here
			std::cout<<"sigh..."<<std::endl;
			std::cin.clear();
			std::cin.ignore(1000,'\n');
		}
		catch (double) { //If we didn't include this, division by zero would terminate the program
			std::cout<<"If you could stop trying to explode the universe, that'd be greeeat..."<<std::endl;
		}
	} while (!valid);
	std::cout<<"Great! The result is: "<<(num/den)<<"!"<<std::endl;
}
