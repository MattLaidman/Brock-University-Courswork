#include <iostream>
//Try not to think of exceptions as being synonymous with errors
//There's certainly a lot of overlap, but there's still a difference

const int YOUNEVERLISTEN=1;
int main() {
	int value;
	std::cout<<"Enter a number from 1 to 5: "<<std::endl;
	std::cin>>value;
	if (value<1 || value>5)
		throw YOUNEVERLISTEN;
	//With nothing to handle this, what's the point? Why not just explicitly exit?
	std::cout<<"This is still pretty bad."<<std::endl;
}
