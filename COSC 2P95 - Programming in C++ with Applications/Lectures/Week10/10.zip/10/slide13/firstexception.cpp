#include <iostream>
//Try not to think of exceptions as being synonymous with errors
//There's certainly a lot of overlap, but there's still a difference

int main() {
	std::cout<<"This is a ludicrous first example."<<std::endl;
	throw 1; //This ALWAYS throws an exception. That's silly.
	std::cout<<"This code can never ever run."<<std::endl;
}
