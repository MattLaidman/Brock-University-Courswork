package Assignment3;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Question2 {

    public static void main(String[] args) { new Question2(); }

    int[][] M;
    int[][] B;
    private Question2( ) {

        int n;
        int[] r;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        try {

            System.out.print("Number of Matrices? : ");
            n = Integer.parseInt(br.readLine());
            System.out.println();
            r = new int[n+1];

            for (int i = 0 ; i < n ; i++) {
                System.out.print("Number of Rows in Matrix " + (i+1) + "? : ");
                r[i] = Integer.parseInt(br.readLine());
            }
            System.out.print("Number of Columns in Matrix " + n + "? : ");
            r[n] = Integer.parseInt(br.readLine());

        } catch(Exception e) {
            return;
        }

        System.out.println(" = " + getMatrixOrder(n, r));
    }

    private int getMatrixOrder (int n, int[] r) {

        M = new int[n][n];
        B = new int[n][n];

        for (int l = 1 ; l < n ; l++)
            for (int i = 0 ; i < n-l ; i++) {
                int j = i + l;
                M[i][j] = Integer.MAX_VALUE;
                for (int k = i ; k < j ; k++) {
                    int t = M[i][k] + M[k+1][j] + r[i]*r[k+1]*r[j+1];
                    if (t < M[i][j]) {
                        M[i][j] = t;
                        B[i][j] = k;
                    }
                }
            }
        System.out.println();
        printOrder(0, n-1);
        return M[0][n-1];
    }

    private void printOrder (int i, int j) {
            if (i == j)
                System.out.print("M"+(i+1));
            else {
                int k = B[i][j];
                System.out.print("(");
                printOrder(i, k);
                printOrder(k + 1, j);
                System.out.print(")");
            }
    }
}
