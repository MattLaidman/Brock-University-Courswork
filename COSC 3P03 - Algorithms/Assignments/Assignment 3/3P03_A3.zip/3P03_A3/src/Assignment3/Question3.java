package Assignment3;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Question3 {

    public static void main (String[] args) { new Question3(); }

    int[] P;
    int m;
    private Question3 ( ) {

        int n;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        m = (int)(1+Math.random()*20); // m is randomly selected on interval [1,100]
        P = new int[m + 1]; // P[0]=0, P[1], ..., P[m]
        P[0] = 0;
        for (int i = 1 ; i <= m ; i++) // P[1] - P[m] randomly selected on interval [-100, 100]
            P[i] = (int)(Math.random()*300-10);

        System.out.println("Maximum number of miles a bus can travel : " + m);
        System.out.println("\nCost to travel :");
        System.out.print("Miles:");
        for (int i = 0 ; i <= m ; i++)
            System.out.print("\t\t" + i);

        System.out.print("\nPrices:");
        for (int i = 0 ; i <= m ; i++)
            System.out.print("\t\t" + P[i]);

        try {
            System.out.print("\n\nNumber of Miles to travel? : ");
            n = Integer.parseInt(br.readLine());
        } catch(Exception e) {
            return;
        }

        System.out.println("\n" + getBusCost(n));
    }

    private int getBusCost (int n) {

        int[][] C = new int[n+1][n+1];

        if (n == 0)
            return 0;
        if (n == 1)
            return P[1];

        for (int l = 1 ; l <= n ; l++)
            for (int i = 0 ; i <= n-l ; i++) {
                int j = l + i;
                int t = Integer.MAX_VALUE;
                for (int s = i + 1 ; s < j ; s++) {
                    int u = C[i][s]+C[s][j];
                    if (u < t)
                        t = u;
                }
                int k = j - i;
                if ((k == 1) || (k <= m && t > P[k]))
                    C[i][j] = P[k];
                else
                    C[i][j] = t;
            }
        return C[0][n];
    }


}
