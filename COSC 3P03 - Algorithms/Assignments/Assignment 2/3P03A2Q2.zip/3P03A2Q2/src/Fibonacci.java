/**
 * COSC 3P03 - Assignment 2, Question 2
 * Matt Laidman
 * 5199807, ml12ef
 * February 9, 2016
 *
 * Implementation of two recursive methods for computing the nth fibonacci number.
 *
 * Method 1 - Standard, slow, O(2^n) recursive algorithm
 * Method 2 - Fast, exponentiation by squaring, O(logn) recursive algorithm
 *
 * Executing the compiled jar from the command line with the first argument as
 * the input for n will output both the value and time taken to compute for both
 * algorithms. If no input argument is provided, 27 is used (chosen arbitrarily).
 */

public class Fibonacci {

    public static void main(String[] args) {
        if (args.length != 0) {
            new Fibonacci(Long.parseLong(args[0]));
        } else {
            new Fibonacci(27);
        }
    }

    private Fibonacci ( long n ) {

        long t1 = System.nanoTime();
        System.out.print("Standard Recursive Function:\n" + fibonacci(n));
        long t2 = System.nanoTime();
        System.out.println(" - " + (t2-t1) + "ns");
        long t3 = System.nanoTime();
        System.out.print("Exponentiation by Squaring Recursive Function:\n" + matrixFibonacci(n));
        long t4 = System.nanoTime();
        System.out.println(" - " + (t4-t3) + "ns");
    }

    private int fibonacci ( long n ) {
        if (n == 0)
            return 0;
        else if (n== 1)
            return 1;
        else
            return fibonacci(n-1) + fibonacci(n-2);
    }

    private long matrixFibonacci ( long n ) {

        if (n == 0)
            return 1;

        long[][] A = new long[2][2];
        A[0][0] = 0;
        A[0][1] = 1;
        A[1][0] = 1;
        A[1][1] = 1;

        return recFib(A, n)[0][1];
    }

    private long[][] recFib (long[][] A, long n) {

        if (n <= 1) {
            return A;
        } else {
            long[][] tmp = recFib(A, n/2);
            long[][] B = new long[2][2];

            B[0][0] = tmp[0][0]*tmp[0][0] + tmp[0][1]*tmp[1][0];
            B[0][1] = tmp[0][0]*tmp[0][1] + tmp[0][1]*tmp[1][1];
            B[1][0] = tmp[1][0]*tmp[0][0] + tmp[1][1]*tmp[1][0];
            B[1][1] = tmp[1][0]*tmp[0][1] + tmp[1][1]*tmp[1][1];
            if ((n & 1) == 0) { // even
                return B;
            } else { // odd
                long[][] C = new long[2][2];
                C[0][0] = B[0][0]*A[0][0] + B[0][1]*A[1][0];
                C[0][1] = B[0][0]*A[0][1] + B[0][1]*A[1][1];
                C[1][0] = B[1][0]*A[0][0] + B[1][1]*A[1][0];
                C[1][1] = B[1][0]*A[0][1] + B[1][1]*A[1][1];
                return C;
            }
        }
    }
}
