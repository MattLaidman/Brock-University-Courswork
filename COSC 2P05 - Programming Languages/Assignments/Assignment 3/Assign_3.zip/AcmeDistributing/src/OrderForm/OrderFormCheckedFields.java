package OrderForm;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

/**
 * OrderFormCheckedFields class is the GridLayout JPanel class for the
 * date, time, item number, order number, and quantity fields (validated
 * fields).
 */


class OrderFormCheckedFields extends JPanel {

    CheckedField date, time, orderNum, itemNum, quantity;

    OrderFormCheckedFields( ) {

        setLayout(new GridLayout(3, 4));
        buildPanel();
    }

    // Build panel method add fields to panel
    private void buildPanel ( ) {

        // Create  Labels
        JLabel dateLabel = new JLabel("Date (DD/MM/YYYY):");
        JLabel timeLabel = new JLabel("Time (hh:mm):");
        JLabel orderNumLabel = new JLabel("Order Number:");
        JLabel itemNumLabel = new JLabel("Item Number:");
        JLabel quantityLabel = new JLabel("Quantity:");

        // Create Fields
        date = new CheckedField(Type.DATE, dateLabel);
        time = new CheckedField(Type.TIME, timeLabel);
        orderNum = new CheckedField(Type.STRING, orderNumLabel);
        itemNum = new CheckedField(Type.STRING, itemNumLabel);
        quantity = new CheckedField(Type.INTEGER, quantityLabel);

        // Add Event Listeners
        date.addFocusListener(new CheckedFieldFocusListener(date));
        time.addFocusListener(new CheckedFieldFocusListener(time));
        orderNum.addFocusListener(new CheckedFieldFocusListener(orderNum));
        itemNum.addFocusListener(new CheckedFieldFocusListener(itemNum));
        quantity.addFocusListener(new CheckedFieldFocusListener(quantity));

        // Add Components to JPanel
        add(dateLabel, 0);
        add(date, 1);
        add(timeLabel, 2);
        add(time, 3);
        add(orderNumLabel, 4);
        add(orderNum, 5);
        add(itemNumLabel, 6);
        add(itemNum, 7);
        add(quantityLabel, 8);
        add(quantity, 9);
    }

    //Checks the validity of all CheckedFields. Invalid fields are marked as such.
    //True is returned if all fields are valid, false is returned otherwise.
    boolean validateAll ( ) {
        return isValid(date) & isValid(time) & isValid(orderNum)
                & isValid(itemNum) & isValid(quantity);
    }

    private boolean isValid (CheckedField cf) {

        String i = cf.getText();
        JLabel l = cf.getLabel();
        boolean valid = true; // Assume form is valid initially

        switch (cf.getType()) {
            case DATE: // DD/MM/YYYY
                if (!i.matches("(([0-2][0-9])|(3[0-1]))/((0[1-9])|(1[0-2]))/([0-9][0-9][0-9][0-9])"))
                    valid = false;
                break;
            case TIME: // hh:mm
                if (!i.matches("(([1][0-9])|([0][0-9])|([2][0-4])):[0-5][0-9]"))
                    valid = false;
                break;
            case INTEGER:
                if (!i.matches("[0-9][0-9]*"))
                    valid = false;
                break;
            case STRING: // Can not be blank
                if (i.equals(""))
                    valid = false;
                break;
        }

        if (valid)
            l.setForeground(Color.black);
        else
            l.setForeground(Color.red);

        return valid;
    }

    void clearFields ( ) {

        date.setText("");
        time.setText("");
        orderNum.setText("");
        itemNum.setText("");
        quantity.setText("");
    }

    String getDate ( ) {return date.getText();}
    void setDate (String s) {date.setText(s);}
    String getTime ( ) {return time.getText();}
    void setTime (String s) {time.setText(s);}
    String getOrderNum ( ) {return orderNum.getText();}
    void setOrderNum (String s) {orderNum.setText(s);}
    String getItemNum ( ) {return itemNum.getText();}
    void setItemNum (String s) {itemNum.setText(s);}
    String getQuantity ( ) {return quantity.getText();}
    void setQuantity (String s) {quantity.setText(s);}

    // CheckedField extends JTextField and adds Type enum attribute
    private class CheckedField extends JTextField {
        private Type type;
        private JLabel label;
        CheckedField (Type t, JLabel l)  {type = t;label = l;}
        Type getType ( ) {return type;}
        JLabel getLabel ( ) {return label;}
    }

    // Focus Event Listener for fields to check validation
    private class CheckedFieldFocusListener implements FocusListener {
        CheckedField field;
        CheckedFieldFocusListener (CheckedField cf) {field = cf;}
        public void focusGained(FocusEvent e) {}
        public void focusLost(FocusEvent e) {isValid(field);}
    }

    // Form Types
    private enum Type {
        DATE,
        TIME,
        INTEGER,
        STRING
    }
}
