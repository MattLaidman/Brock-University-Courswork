package OrderForm;

import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;

/**
 * OrderFormButtons class is the FlowLayout JPanel class for the buttons.
 */

class OrderFormButtons extends JPanel {

    OrderFormButtons (ActionListener buttonListener) {

        setLayout(new FlowLayout());
        buildPanel(buttonListener);
    }

    // Construct the JPanel
    private void buildPanel (ActionListener buttonListener) {

        // Create Buttons
        JButton ok = new JButton("OK");
        JButton quit = new JButton("Quit");

        // Set Action Commands
        ok.setActionCommand("OK");
        quit.setActionCommand("Quit");

        // Set Action Listeners
        ok.addActionListener(buttonListener);
        quit.addActionListener(buttonListener);

        // Add Buttons to JPanel
        add(ok);
        add(quit);
    }
}
