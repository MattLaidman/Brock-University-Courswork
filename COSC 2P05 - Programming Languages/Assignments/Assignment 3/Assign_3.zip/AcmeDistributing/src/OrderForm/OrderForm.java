package OrderForm;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * COSC 2P05 - Assignment 3
 * Matt Laidman
 * 5199807, ml12ef
 *
 * Upon execution, user will be displayed the "Acme Distributing" order form along with any orders
 * that are in the queue. Pressing OK will cause the next item in the queue to be displayed until
 * there are no items left, at which point a blank form will be displayed. When the user correctly
 * fills  out the form, and presses either OK or Quit, the item will be added into the queue.
 *
 * The queue is stored in the "OrderQueue" file.
 */
public class OrderForm extends JFrame implements ActionListener {

    OrderFormCheckedFields checkedFields;
    OrderFormUncheckedFields uncheckedFields;
    Queue<Order> orderQueue, viewedQueue; // Queues for for unviewed and viewed orders
    Order cOrder;
    File qFile;

    @SuppressWarnings("all")
    public OrderForm ( ) {

        qFile = new File ("OrderQueue");
        viewedQueue = new LinkedBlockingQueue<>();
        BufferedReader br;
        try { // Tryto read file
            br = new BufferedReader(new FileReader(qFile));
            if (br.readLine() == null) { // if file empty
                System.err.println("File OrderQueue found but empty.");
                orderQueue = new LinkedBlockingQueue<>(); // Make a new order queue
            } else { // else file not empty
                try  { // try to read in data
                    ObjectInputStream in = new ObjectInputStream (new FileInputStream(qFile));
                    orderQueue = (LinkedBlockingQueue<Order>)in.readObject();
                } catch (Exception e) { // Invalid data
                    System.err.println("File OrderQueue found but contains corrupt or invalid data.");
                    throw new Exception();  // Raise exception to be caught
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Order queue file not found in expected location, is invalid, " +
                    "or is unreadable.\nA new, empty queue will be created.");
            try { // try to make a new file
                if (qFile.exists())
                    qFile.delete();
                qFile.createNewFile();
                orderQueue = new LinkedBlockingQueue<>(); // Make a new order queue
            } catch (IOException ioe) { // quit if error still because like come on
                JOptionPane.showMessageDialog(null, "Error creating file. Quiting.");
                return;
            }
        }
        setLayout(new BorderLayout()); // Set layout of JFrame
        buildFrame();
        pack();
        setVisible(true);
        if (!orderQueue.isEmpty()) { // order queue is not empty, set fields on form
            cOrder = orderQueue.remove();
            checkedFields.setDate(cOrder.getDate());
            checkedFields.setTime(cOrder.getTime());
            checkedFields.setOrderNum(cOrder.getOrderNum());
            checkedFields.setItemNum(cOrder.getItemNum());
            checkedFields.setQuantity(cOrder.getQuantity());
            uncheckedFields.setAddress(cOrder.getAddress());
        }
    }

    // buildFrame method creates and add the JPanels to the JFrame (this)
    private void buildFrame ( ) {

        // Create JPanels
        checkedFields = new OrderFormCheckedFields();
        uncheckedFields = new OrderFormUncheckedFields();
        OrderFormButtons buttons = new OrderFormButtons(this);

        // Add JPanels to JFrame
        add(checkedFields, BorderLayout.NORTH);
        add(uncheckedFields, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
    }

    //Action listenener for buttons
    @Override
    @SuppressWarnings("all")
    public void actionPerformed(ActionEvent e) {
        boolean valid;
        if (e.getActionCommand().equals("OK")) { // OK is pushed
            valid = checkedFields.validateAll();
            if (valid) {
                cOrder = new Order(checkedFields.getDate(), checkedFields.getTime(), checkedFields.getOrderNum(),
                        checkedFields.getItemNum(), checkedFields.getQuantity(), uncheckedFields.getAddress());
                viewedQueue.add(cOrder); // add to viewed queue
                checkedFields.clearFields(); // clear
                uncheckedFields.clearFields();
                if (!orderQueue.isEmpty()) { // set next object if there is one
                    cOrder = orderQueue.remove();
                    checkedFields.setDate(cOrder.getDate());
                    checkedFields.setTime(cOrder.getTime());
                    checkedFields.setOrderNum(cOrder.getOrderNum());
                    checkedFields.setItemNum(cOrder.getItemNum());
                    checkedFields.setQuantity(cOrder.getQuantity());
                    uncheckedFields.setAddress(cOrder.getAddress());
                }
            }
        } else { // Quit is pushed
            try { // try to save queue
                ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(qFile));
                out.writeObject(viewedQueue);
            } catch (Exception ex) { // error saving to file
                try { // try to create new file first
                    System.err.println("Error saving to file, creating new file.");
                    qFile.createNewFile();
                    ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(qFile));
                    out.writeObject(viewedQueue);
                } catch (Exception exc) { // Still unable.. So yea, don't save I guess
                    JOptionPane.showMessageDialog(null, "Unable to create save file, or error saving queue.\n" +
                            "Order queue not saved.");
                }
            }
            setVisible(false);
            dispose();
        }
    }

    // Private order object class
    private class Order implements Serializable {
        private String date, time, orderNum, itemNum, quantity, address;
        Order (String date, String time, String orderNum, String itemNum, String quantity, String address) {
            this.date = date;
            this.time = time;
            this.orderNum = orderNum;
            this.itemNum = itemNum;
            this.quantity = quantity;
            this.address = address;
        }
        String getDate ( ) {return date;}
        String getTime ( ) {return time;}
        String getOrderNum ( ) {return orderNum;}
        String getItemNum ( ) {return itemNum;}
        String getQuantity ( ) {return quantity;}
        String getAddress ( ) {return address;}
    }

    public static void main (String[] argv) {new OrderForm();}
}
