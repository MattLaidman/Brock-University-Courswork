import Forms.ClerkForm;
import Forms.Order;
import Forms.ShippingForm;

import javax.swing.JOptionPane;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.concurrent.LinkedBlockingQueue;


/**
 * AcmeDistributing class is main driver. Creates the order queue and starts the clerk
 * and shipping forms. It then waits in the background until they are closed, at which
 * point it saves any orders remaining in the queue to the file OrderQueue.
 *
 * The forms are their own event handlers and an Event Driver Thread has not been used
 * as the two forms perform different operations, submitting an order to the buffer and
 * removing an order from the buffer, neither of which will block.
 *
 * The Main containers for the forms are ClerkForm and ShippingForm; both of which extend
 * JFrame and are built using the FormTextFields_*, FormTextArea, and FormButtons classes,
 * which extend JPanel.
 *
 * SwingWorker subclasses have been used to do the actual submitting and retrieval of
 * the order to and from the buffer. This is done in the background so as not to block.
 * The shipping form is updated when the order is ready, and the clerk form is cleared
 * as soon as the order information has been saved to memory for submission by the
 * SwingWorker.
 */

public class AcmeDistributing implements Runnable {

    LinkedBlockingQueue<Order> orderQueue;
    File qFile;
    ClerkForm cForm;
    ShippingForm sForm;

    public AcmeDistributing ( ) {
        if (getQueue()) { // if getting/making new queue succeeds
            cForm = new ClerkForm(orderQueue); // Make a clerk form
            sForm = new ShippingForm(orderQueue); // Make a shipping form
            cForm.setVisible(true); // Make them both visible
            sForm.setVisible(true);
            run(); // wait in background until forms are closed
        } else {
            System.err.println("Unable to load queue, or create new queue.\n");
        }
    }

    @SuppressWarnings("all")
    boolean getQueue ( ) {

        qFile = new File ("OrderQueue");
        BufferedReader br;

        try { // Try to read file
            br = new BufferedReader(new FileReader(qFile));
            if (br.readLine() == null) { // if file empty
                System.err.println("File OrderQueue found but empty.");
                orderQueue = new LinkedBlockingQueue<Order>(); // Make a new order queue
            } else { // else file not empty
                try  { // try to read in data
                    ObjectInputStream in = new ObjectInputStream (new FileInputStream(qFile));
                    orderQueue = (LinkedBlockingQueue<Order>)in.readObject();
                } catch (Exception e) { // Invalid data
                    System.err.println("File OrderQueue found but contains corrupt or invalid data.");
                    throw new Exception();  // Raise exception to be caught
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Order queue file not found in expected location, is invalid, " +
                    "or is unreadable.\nA new, empty queue will be created.");
            try { // try to make a new file
                if (qFile.exists())
                    qFile.delete();
                qFile.createNewFile();
                orderQueue = new LinkedBlockingQueue<Order>(); // Make a new order queue
            } catch (IOException ioe) { // quit if error still because like come on
                JOptionPane.showMessageDialog(null, "Error creating file. Quiting.");
                return false;
            }
        }
        return true;
    }


    @Override
    @SuppressWarnings("all")
    public void run() {

        while (cForm.isVisible() || sForm.isVisible()) {
            try {Thread.sleep(1000);} catch (Exception ignore) {}
        }

        try { // try to save queue
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(qFile));
            out.writeObject(orderQueue);
            System.err.println("Queue Saved.");
        } catch (Exception ex) { // error saving to file
            try { // try to create new file first
                System.err.println("Error saving to file, creating new file.");
                qFile.createNewFile();
                ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(qFile));
                out.writeObject(orderQueue);
            } catch (Exception exc) { // Still unable.. So yea, don't save I guess
                JOptionPane.showMessageDialog(null, "Unable to create save file, or error saving queue.\n" +
                        "Order queue not saved.");
            }
        }
    }

    public static void main (String[] argv) {new AcmeDistributing();}
}
