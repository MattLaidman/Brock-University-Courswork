package Forms;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import java.awt.FlowLayout;

/**
 * Unchecked TextArea JPanel class
 */

class FormTextArea extends JPanel {

    private JTextArea address;

    FormTextArea ( ) {

        setLayout(new FlowLayout());
        buildPanel();
    }

    // construct the JPanel
    private void buildPanel ( ) {

        // Create Label
        JLabel addressLabel = new JLabel("Address:");

        // Create Text Area
        address = new JTextArea();
        address.setRows(5);
        address.setColumns(60);

        // Add Components to JPanel
        add(addressLabel);
        add(address);
    }

    void setEditable (boolean b) {address.setEditable(b);}
    void clearField ( ) {address.setText("");}

    String getAddress ( ) {return address.getText();}
    void setAddress (String s) {address.setText(s);}
}
