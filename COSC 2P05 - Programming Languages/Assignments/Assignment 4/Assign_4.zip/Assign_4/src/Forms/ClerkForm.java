package Forms;

import javax.swing.JFrame;
import javax.swing.SwingWorker;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Clerk form class
 *
 * See "AcmeDistributing" class
 */

public class ClerkForm extends JFrame implements ActionListener {

    FormTextFields_Checked fields;
    FormTextArea area;
    LinkedBlockingQueue<Order> queue;

    public ClerkForm(LinkedBlockingQueue<Order> queue) {

        this.queue = queue;
        buildForm();
        pack();
        setLocationRelativeTo(null);
        setLocation(getX(), getY() - 105);
    }

    private void buildForm() {

        setLayout(new BorderLayout());

        fields = new FormTextFields_Checked();
        area = new FormTextArea();
        FormButtons buttons = new FormButtons(this);

        add(fields, BorderLayout.NORTH);
        add(area, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
    }

    private Order getOrder ( ) {

        if (fields.validateAll()) {
            return new Order(fields.getDate(), fields.getTime(), fields.getOrderNum(),
                    fields.getItemNum(), fields.getQuantity(), area.getAddress());
        } else {
            return null;
        }
    }

    private void clearFields ( ) {

        fields.clearFields();
        area.clearField();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("OK")) {
            new BufferWriter().doInBackground();
        } else { // else quit
            setVisible(false);
            dispose();
        }
    }

    private class BufferWriter extends SwingWorker<Void, Order> {

        @Override
        protected Void doInBackground ( ) {
            Order o = getOrder();
            if (o != null) {
                clearFields();
                publish(o);
            }
            return null;
        }

        @Override
        protected void process (List<Order> orders) {
            queue.add(orders.get(orders.size()-1));
        }
    }
}
