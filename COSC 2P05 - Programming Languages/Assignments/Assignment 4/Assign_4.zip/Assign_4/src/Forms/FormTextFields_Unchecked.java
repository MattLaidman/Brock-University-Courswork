package Forms;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.GridLayout;

/**
 * Unchecked Fields JPanel class
 */

class FormTextFields_Unchecked extends JPanel {
    UncheckedField date, time, orderNum, itemNum, quantity;

    FormTextFields_Unchecked( ) {

        setLayout(new GridLayout(3, 4));
        buildPanel();
    }

    // Build panel method add fields to panel
    private void buildPanel ( ) {

        // Create  Labels
        JLabel dateLabel = new JLabel("Date (DD/MM/YYYY):");
        JLabel timeLabel = new JLabel("Time (hh:mm):");
        JLabel orderNumLabel = new JLabel("Order Number:");
        JLabel itemNumLabel = new JLabel("Item Number:");
        JLabel quantityLabel = new JLabel("Quantity:");

        // Create Fields
        date = new UncheckedField(dateLabel);
        time = new UncheckedField(timeLabel);
        orderNum = new UncheckedField(orderNumLabel);
        itemNum = new UncheckedField(itemNumLabel);
        quantity = new UncheckedField(quantityLabel);

        // Set uneditable
        date.setEditable(false);
        time.setEditable(false);
        orderNum.setEditable(false);
        itemNum.setEditable(false);
        quantity.setEditable(false);

        // Add Components to JPanel
        add(dateLabel, 0);
        add(date, 1);
        add(timeLabel, 2);
        add(time, 3);
        add(orderNumLabel, 4);
        add(orderNum, 5);
        add(itemNumLabel, 6);
        add(itemNum, 7);
        add(quantityLabel, 8);
        add(quantity, 9);
    }

    void clearFields ( ) {

        date.setText("");
        time.setText("");
        orderNum.setText("");
        itemNum.setText("");
        quantity.setText("");
    }

    String getDate ( ) {return date.getText();}
    void setDate (String s) {date.setText(s);}
    String getTime ( ) {return time.getText();}
    void setTime (String s) {time.setText(s);}
    String getOrderNum ( ) {return orderNum.getText();}
    void setOrderNum (String s) {orderNum.setText(s);}
    String getItemNum ( ) {return itemNum.getText();}
    void setItemNum (String s) {itemNum.setText(s);}
    String getQuantity ( ) {return quantity.getText();}
    void setQuantity (String s) {quantity.setText(s);}

    // CheckedField extends JTextField and adds Type enum attribute
    private class UncheckedField extends JTextField {
        private JLabel label;
        UncheckedField (JLabel l)  {label = l;}
        JLabel getLabel ( ) {return label;}
    }
}