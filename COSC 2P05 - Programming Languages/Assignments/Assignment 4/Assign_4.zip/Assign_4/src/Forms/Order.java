package Forms;

import java.io.Serializable;

/**
 * Simple Order object
 */

public class Order implements Serializable {
    private String date, time, orderNum, itemNum, quantity, address;
    Order (String date, String time, String orderNum, String itemNum, String quantity, String address) {
        this.date = date;
        this.time = time;
        this.orderNum = orderNum;
        this.itemNum = itemNum;
        this.quantity = quantity;
        this.address = address;
    }
    String getDate ( ) {return date;}
    String getTime ( ) {return time;}
    String getOrderNum ( ) {return orderNum;}
    String getItemNum ( ) {return itemNum;}
    String getQuantity ( ) {return quantity;}
    String getAddress ( ) {return address;}
}