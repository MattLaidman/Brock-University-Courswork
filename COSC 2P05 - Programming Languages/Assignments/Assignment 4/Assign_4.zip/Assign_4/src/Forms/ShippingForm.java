package Forms;

import javax.swing.JFrame;
import javax.swing.SwingWorker;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Shipping form class
 *
 * See "AcmeDistributing" class
 */

public class ShippingForm extends JFrame implements ActionListener {

    FormTextFields_Unchecked fields;
    FormTextArea area;
    LinkedBlockingQueue<Order> orderQueue;

    public ShippingForm (LinkedBlockingQueue<Order> orderQueue) {

        this.orderQueue = orderQueue;

        buildForm();
        pack();
        setLocationRelativeTo(null);
        setLocation(getX(), getY()+105);
    }

    private void buildForm () {

        setLayout(new BorderLayout());

        fields = new FormTextFields_Unchecked();
        area = new FormTextArea();
        FormButtons buttons = new FormButtons(this);

        area.setEditable(false);

        add(fields, BorderLayout.NORTH);
        add(area, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
    }

    private Order getOrder ( ) {

        return new Order(fields.getDate(), fields.getTime(), fields.getOrderNum(),
                fields.getItemNum(), fields.getQuantity(), area.getAddress());
    }

    private void clearFields ( ) {

        fields.clearFields();
        area.clearField();
    }

    private void setFields (Order o) {
        fields.setDate(o.getDate());
        fields.setTime(o.getTime());
        fields.setOrderNum(o.getOrderNum());
        fields.setItemNum(o.getItemNum());
        fields.setQuantity(o.getQuantity());
        area.setAddress(o.getAddress());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("OK")) {
            Order order = new BufferReader().doInBackground();
            if (order == null) {
                clearFields();
            } else {
                setFields(order);
            }
        } else { // else quit
            setVisible(false);
            dispose();
        }
    }

    private class BufferReader extends SwingWorker <Order, Void> {

        @Override
        protected Order doInBackground() {
            clearFields();
            try {
                if (orderQueue.size() != 0) {
                    return orderQueue.take();
                }
            } catch (Exception ignore) {
            }
            return null;
        }
    }
}
