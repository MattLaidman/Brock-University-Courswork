import ATM.*;
import BasicIO.*;

import java.io.File;

/**
 * COSC 2P05 - Assignment 1
 * Matt Laidman
 * 5199807, ml12ef
 * February 8, 2015
 *
 * Bank of St Kitts
 *
 * Upon execution, both interface a will load asper assignment specifications. data from client.txt file into
 * customer object with appropriate accounts will load as per assignment specifications. Selecting accounts
 * and clicking the buttons will cause the appropriate action to run.
 */

public class BankOfStKitts {

    private BasicForm form;
    private Client customer;

    public BankOfStKitts ( ) {

        customer = new Client();
        getCustomer(); // get data for client
        buildForm(customer, customer.getNumAccounts(), false);
        runATM(); // main UI loop
    } // Constructor

    private void runATM ( ) {


        File lFile = new File("src/log.txt");
        ASCIIOutputFile log = new ASCIIOutputFile(lFile);
        Account acc, acc2;
        int accNum;
        double amt;
        double preBal, postBal, preBal2, postBal2;
        boolean accepted;

        while (true) { // loop until quit

            switch (form.accept()) { // wait for input, switch button pressed

                case 0: // Balance Inquiry

                    accNum = form.readInt("account");
                    if (accNum == -1) { // Ensure account was selected
                        form.clearAll();
                        break;
                    }
                    form.close(); // rebuild form
                    buildForm(customer, customer.getNumAccounts(), true);
                    form.writeDouble("textfield", customer.getAccount(accNum).getBalance(), Formats.getCurrencyInstance());
                    form.show();
                    form.accept();
                    form.close();
                    buildForm(customer, customer.getNumAccounts(), false);
                    form.show();
                    break;

                case 1: // Deposit

                    accNum = form.readInt("account");
                    if (accNum == -1) {
                        form.clearAll();
                        break;
                    }
                    amt = form.readFloat("amount");
                    if (amt <= 0) {
                        form.clearAll();
                        break;
                    }
                    acc = customer.getAccount(accNum);
                    preBal = acc.getBalance();
                    if (acc.deposit(amt)) {
                        accepted = true;
                        postBal = acc.getBalance();
                        customer.setAccount(acc, accNum);
                        form.clearAll();
                    } else {
                        accepted = false;
                        postBal = acc.getBalance();
                        form.close();
                        buildForm(customer, customer.getNumAccounts(), true);
                        form.writeString("textfield", "Unable to complete deposit to account " + acc.getDescription());
                        form.show();
                        form.accept();
                        form.close();
                        buildForm(customer, customer.getNumAccounts(), false);
                        form.show();
                    }
                    log.writeLine("deposit: " + amt + "\tto: " + acc.getNumber() + "\torig: " + preBal +
                        "\tnew: " + postBal + "\t" + (accepted ? "successful" : "rejected"));
                    break;

                case 2: // Withdrawal

                    accNum = form.readInt("account");
                    if (accNum == -1) {
                        form.clearAll();
                        break;
                    }
                    amt = form.readFloat("amount");
                    if (amt <= 0) {
                        form.clearAll();
                        break;
                    }
                    acc = customer.getAccount(accNum);
                    preBal = acc.getBalance();
                    if (acc.withdraw(amt)) {
                        postBal = acc.getBalance();
                        accepted = true;
                        customer.setAccount(acc, accNum);
                        form.clearAll();
                    } else {
                        accepted = false;
                        postBal = acc.getBalance();
                        form.close();
                        buildForm(customer, customer.getNumAccounts(), true);
                        form.writeString("textfield", "Unable to complete withdrawal from " + acc.getDescription());
                        form.show();
                        form.accept();
                        form.close();
                        buildForm(customer, customer.getNumAccounts(), false);
                        form.show();
                    }
                    log.writeLine("withdraw: " + amt + "\tfrom: " + acc.getNumber() + "\torig: " + preBal +
                            "\tnew: " + postBal + "\t" + (accepted ? "successful" : "rejected"));
                    break;

                case 3: // Transfer

                    accNum = form.readInt("account");
                    int accNum2 = form.readInt("otherAccount");
                    if (accNum == -1 || accNum2 == -1) {
                        form.clearAll();
                        break;
                    }
                    amt = form.readFloat("amount");
                    if (amt <= 0) {
                        form.clearAll();
                        break;
                    }
                    acc = customer.getAccount(accNum);
                    acc2 = customer.getAccount(accNum2);
                    preBal = acc.getBalance();
                    preBal2 = acc2.getBalance();
                    if (acc.couldWithdraw(amt) && acc2.couldDeposit(amt)) { // ensure transfer is valid for both
                        acc.withdraw(amt);
                        acc2.deposit(amt);
                        postBal = acc.getBalance();
                        postBal2 = acc2.getBalance();
                        accepted = true;
                        customer.setAccount(acc, accNum);
                        customer.setAccount(acc2, accNum2);
                        form.clearAll();
                    } else { // failed message
                        accepted = false;
                        postBal = acc.getBalance();
                        postBal2 = acc2.getBalance();
                        form.close();
                        buildForm(customer, customer.getNumAccounts(), true);
                        form.writeString("textfield", "transfer between " + acc.getDescription() + ", " +
                                acc2.getDescription() + " rejected");
                        form.show();
                        form.accept();
                        form.close();
                        buildForm(customer, customer.getNumAccounts(), false);
                        form.show();
                    }
                    log.writeLine("transfer: " + amt + "\tfrom: " + acc.getNumber() + " orig: " + preBal +
                            "\tto: " + acc2.getNumber() + " orig: " + preBal2 +
                            "\tto: new: " + postBal + "\tfrom: new: " + postBal2 + "\t" +
                            (accepted ? "successful" : "rejected"));
                    break;

                case 4: // Quit

                    int numAccounts = customer.getNumAccounts();
                    for (int i = 0 ; i < numAccounts ; i++) {
                        customer.setAccount(customer.getAccount(i).updateBalance(), i);
                    }
                    saveCustomer();
                    log.close();
                    form.close();
                    return;
            }
        }
    }

    private void buildForm ( Client customer, int numAccounts, boolean okForm ) {

        if (okForm) {
            form = new BasicForm();
        } else {
            form = new BasicForm("Balance", "Deposit", "Withdraw",
                    "Transfer", "Quit");
        }
        form.setTitle("Bank of St. Kitts");
        switch (numAccounts) {
            case 1:
                form.addRadioButtons("account", "Account", true, 30, 10, customer.getAccount(0).getDescription());
                break;
            case 2:
                form.addRadioButtons("account", "Account", true, 30, 10, customer.getAccount(0).getDescription(),
                        customer.getAccount(1).getDescription());
                break;
            case 3:
                form.addRadioButtons("account", "Account", true, 30, 10, customer.getAccount(0).getDescription(),
                        customer.getAccount(1).getDescription(), customer.getAccount(2).getDescription());
                break;
            case 4:
                form.addRadioButtons("account", "Account", true, 30, 10, customer.getAccount(0).getDescription(),
                        customer.getAccount(1).getDescription(), customer.getAccount(2).getDescription(),
                        customer.getAccount(3).getDescription());
                break;
            case 5:
                form.addRadioButtons("account", "Account", true, 30, 10, customer.getAccount(0).getDescription(),
                        customer.getAccount(1).getDescription(), customer.getAccount(2).getDescription(),
                        customer.getAccount(3).getDescription(), customer.getAccount(4).getDescription());
                break;
        }// ... This is the best way that I could think of to do this...

        form.addTextField("amount", "Amount", Formats.getDecimalInstance(2), 15, 160, 30);

        switch (numAccounts) {
            case 1:
                form.addRadioButtons("otherAccount", "Other Account", true, 345, 10, customer.getAccount(0).getDescription());
                break;
            case 2:
                form.addRadioButtons("otherAccount", "Other Account", true, 345, 10, customer.getAccount(0).getDescription(),
                        customer.getAccount(1).getDescription());
                break;
            case 3:
                form.addRadioButtons("otherAccount", "Other Account", true, 345, 10, customer.getAccount(0).getDescription(),
                        customer.getAccount(1).getDescription(), customer.getAccount(2).getDescription());
                break;
            case 4:
                form.addRadioButtons("otherAccount", "Other Account", true, 345, 10, customer.getAccount(0).getDescription(),
                        customer.getAccount(1).getDescription(), customer.getAccount(2).getDescription(),
                        customer.getAccount(3).getDescription());
                break;
            case 5:
                form.addRadioButtons("otherAccount", "Other Account", true, 345, 10, customer.getAccount(0).getDescription(),
                        customer.getAccount(1).getDescription(), customer.getAccount(2).getDescription(),
                        customer.getAccount(3).getDescription(), customer.getAccount(4).getDescription());
                break;
        } // ... This is the best way that I could think of to do this...

        form.addTextField("textfield", 63, 23, 140);
    }

    private void getCustomer ( ) {

        File cFile = new File("src/client.txt");
        ASCIIDataFile client = new ASCIIDataFile(cFile);
        int numAccounts;

        customer.setClientNumber(client.readInt()); // first int in number
        customer.setPin(client.readInt()); // second is pin... "not very secure..."
        numAccounts = client.readInt(); // third is num accounts
        for (int i = 0 ; i < numAccounts ; i++) { // Next lines are account info
            String line = client.readLine();
            String[] splitLine = line.split("\\t");
            switch (splitLine[0]) { // switch account type
                case "c":
                    customer.setAccount(new ChequingAccount().setNumber(Integer.parseInt(splitLine[1])).
                            setDescription(splitLine[2]).setBalance(Double.parseDouble(splitLine[3])).setType('c'), i);
                    break;
                case "s":
                    customer.setAccount(new SavingsAccount().setNumber(Integer.parseInt(splitLine[1])).
                            setDescription(splitLine[2]).setBalance(Double.parseDouble(splitLine[3])).setType('s'), i);
                    break;
                case "i":
                    customer.setAccount(new InvestmentAccount().setNumber(Integer.parseInt(splitLine[1])).
                            setDescription(splitLine[2]).setBalance(Double.parseDouble(splitLine[3])).setType('i'), i);
                    break;
                case "x":
                    customer.setAccount(new StudentAccount().setNumber(Integer.parseInt(splitLine[1])).
                            setDescription(splitLine[2]).setBalance(Double.parseDouble(splitLine[3])).setType('x'), i);
                    break;
            }
        }
        client.close();
    }

    @SuppressWarnings("ResultOfMethodCallIgnored")
    private void saveCustomer ( ) {

        File cFile = new File("src/client.txt");
        cFile.delete(); // maybe not necessary...
        try {
            cFile.createNewFile();
        } catch (Exception e) {
            e.printStackTrace();
        }
        ASCIIOutputFile client = new ASCIIOutputFile(cFile);

        client.writeInt(customer.getClientNumber());
        client.writeInt(customer.getPin());
        client.writeLine("\t" + Integer.toString(customer.getNumAccounts()));

        Account acc;

        for (int i = 0 ; i < customer.getNumAccounts() ; i++) {
            acc = customer.getAccount(i);
            client.writeString(Character.toString(acc.getType()));
            client.writeInt(acc.getNumber());
            client.writeString(acc.getDescription());
            client.writeLine("\t" + Double.toString(acc.getBalance()));
        }
        client.close();
    }

    public static void main ( String[] args ) { new BankOfStKitts(); }
}
