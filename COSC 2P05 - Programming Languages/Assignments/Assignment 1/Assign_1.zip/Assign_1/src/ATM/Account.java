package ATM;

public abstract class Account {

    private int number;
    private String description;
    private double balance;
    private char type;

    public Account ( ) { }

    public Account setNumber(int number) {
        this.number = number;
        return this;
    }

    public int getNumber() {
        return number;
    }

    public Account setDescription(String description) {
        this.description = description;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public Account setBalance(double balance) {
        this.balance = balance;
        return this;
    }

    public double getBalance() {
        return balance;
    }

    public Account setType(char type) {
        this.type = type;
        return this;
    }

    public char getType() {
        return type;
    }

    public boolean deposit (double amount ) {

        setBalance(getBalance() + amount);
        return true;
    }

    public boolean couldDeposit ( double amount ) {

        return true;
    }

    public boolean couldWithdraw ( double amount ) {

        return true;
    }

    public abstract boolean withdraw ( double amount );
    public abstract Account updateBalance ( ); // calculate interest

}
