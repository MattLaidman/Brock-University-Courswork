package ATM;

public class ChequingAccount extends Account {

    public boolean withdraw ( double amount ) {

        setBalance(getBalance() - amount - 1);
        return true;
    }

    public Account updateBalance ( ) {

        double balance = getBalance();
        if (balance < 0) {
            setBalance(balance*(1-0.018));
        }
        return this;
    }
}
