package ATM;

public class Client {

    private int clientNumber;
    private int pin;
    private Account[] account;

    public Client ( ) {

        account = new Account[5];
    }

    public void setClientNumber(int clientNumber) {
        this.clientNumber = clientNumber;
    }

    public int getClientNumber() {
        return clientNumber;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public int getPin() {
        return pin;
    }

    public void setAccount(Account account, int i) {
        this.account[i] = account;
    }

    public Account getAccount(int i) {
        return account[i];
    }

    public int getNumAccounts ( ) {
        return  account.length;
    }
}
