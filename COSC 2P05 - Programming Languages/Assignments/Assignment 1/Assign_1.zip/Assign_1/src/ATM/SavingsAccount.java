package ATM;

public class SavingsAccount extends Account {

    public boolean withdraw ( double amount ) {

        double balance = getBalance();
        if (balance < amount) {
            return false;
        }
        if (balance < 1000) {
            if (balance < amount + 0.5) {
                return false;
            } else {
                setBalance(getBalance() - amount - 0.5);
                return true;
            }
        }
        setBalance(getBalance() - amount);
        return true;
    }

    public boolean couldWithdraw ( double amount ) {

        double balance = getBalance();
        if (balance < amount) {
            return false;
        }
        if (balance < 1000) {
            if (balance < amount + 0.5) {
                return false;
            }
        }
        return true;
    }

    public Account updateBalance ( ) {
        setBalance(getBalance()*1.013);
        return this;
    }
}
