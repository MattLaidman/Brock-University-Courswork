package ATM;

public class StudentAccount extends Account {

    public boolean withdraw ( double amount ) {

        double balance = getBalance();
        if (balance < amount) {
            return false;
        }
        setBalance(getBalance() - amount);
        return true;
    }

    @Override
    public boolean couldWithdraw ( double amount ) {

        double balance = getBalance();
        return balance >= amount;
    }

    public Account updateBalance ( ) {
        setBalance(getBalance()*1.015);
        return this;
    }
}
