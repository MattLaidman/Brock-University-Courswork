package ATM;

public class InvestmentAccount extends Account {

    @Override
    public boolean deposit ( double amount ) {

        if (amount < 500) {
            return false;
        }

        setBalance(getBalance() + amount);
        return true;
    }

    public boolean withdraw ( double amount ) {

        if (amount < 500) {
            return false;
        }

        double balance = getBalance();
        if (balance < amount) {
            return false;
        }
        if (balance < 2000) {
            if (balance < amount + 1) {
                return false;
            } else {
                setBalance(getBalance() - amount - 1);
            }
        }
        setBalance(getBalance() - amount);
        return true;
    }

    @Override
    public boolean couldDeposit ( double amount ) {

        return amount >= 500;
    }

    @Override
    public boolean couldWithdraw ( double amount ) {

        if (amount < 500) {
            return false;
        }

        double balance = getBalance();
        if (balance < amount) {
            return false;
        }
        if (balance < 2000) {
            if (balance < amount + 1) {
                return false;
            }
        }
        return true;
    }

    public Account updateBalance ( ) {

        setBalance(getBalance()*(1-0.015));
        return this;
    }
}
