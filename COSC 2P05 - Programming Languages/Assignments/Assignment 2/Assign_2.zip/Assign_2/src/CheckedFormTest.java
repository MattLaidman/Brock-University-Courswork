import CheckedForm.*;

public class CheckedFormTest {

    public CheckedFormTest ( ) {

        CheckedForm form = new CheckedForm();
        form.setTitle("CheckedForm Test");
        form.addField("date", "Date", Type.DATE);
        form.addField("currency", "Currency", Type.CURRENCY);
        form.addField("percent", "Percent", Type.PERCENT);
        form.addField("time", "Time", Type.TIME);
        form.addField("decimal", "Decimal", Type.DECIMAL);
        form.addField("integer", "Integer", Type.INTEGER);
        form.addField("string", "String", Type.STRING);
        form.addText("text1", "Text1");
        form.addText("text2", "Text2");
        form.accept();
        System.out.println(form.readField("date"));
        System.out.println(form.readField("currency"));
        System.out.println(form.readField("percent"));
        System.out.println(form.readField("time"));
        System.out.println(form.readField("decimal"));
        System.out.println(form.readField("integer"));
        System.out.println(form.readField("string"));
        System.out.println(form.readField("text1"));
        System.out.println(form.readField("text2"));
    }

    public static void main (String[] args) {new CheckedFormTest();}
}
