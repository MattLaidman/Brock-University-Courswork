package CheckedForm;

public enum Type {

    DATE,
    TIME,
    CURRENCY,
    DECIMAL,
    INTEGER,
    PERCENT,
    STRING
}
