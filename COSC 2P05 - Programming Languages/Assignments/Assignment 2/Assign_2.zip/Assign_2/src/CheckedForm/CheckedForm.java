/**
 * Matt Laidman
 * 5199807
 *
 * COSC 2P05 - Assignment 2
 * February 29, 2015
 */

package CheckedForm;

import BasicIO.BasicForm;

import java.util.LinkedList;
import java.util.List;

public class CheckedForm {

    BasicForm form;
    List<FormField> formFields = new LinkedList<>();
    List<FormArea> formAreas = new LinkedList<>();

    public CheckedForm ( ) {
        form = new BasicForm("OK", "Quit");
    }

    public void setTitle (String title) {

        form.setTitle(title);
    }

    public void addField (String name, String label, Type kind) {

        formFields.add(new FormField(name, label, kind));
    }

    public void addText (String name, String label) {

        formAreas.add(new FormArea(name, label));
    }

    public String readField (String name) {

        return form.readLine(name);
    }

    public String readText (String name) {

        String text = "";
        String line = form.readLine(name);
        while (line != null) {
            text+=(line + "\n");
            line = form.readLine(name);
        }
        return text.substring(0, text.length()-1);
    }

    public int accept ( ) {

        // build form
        buildForm();
        form.clearAll();
        // accept form
        while (true) {
            if (form.accept() != 0) { // Quit
                form.close();
                return 1;
            } else {
                form.hide();
                if (validate()) {
                    return 0;
                }
            }
        }
    }

    // I couldn't figure out the BasicIO formats... I hope this is okay?
    @SuppressWarnings("all")
    private boolean validate ( ) {

        boolean valid = true;

        for (int i = 0 ; i < formFields.size() ; i++) {
            FormField curField = formFields.get(i);
            String input = form.readLine(curField.name);
            switch (curField.kind) {
                case DATE:
                    if (!input.matches("((0[1-9])|(1[0-2]))-(([0-2][0-9])|(3[0-1]))-[0-9][0-9]")) {
                        valid = false;
                        try { // Why can you not remove an item from BasicForm?!?!
                            form.addLabel("Err" + i, "Fix Me!", 10 + ((i % 2) * 260), 30 + (i / 2) * 60);
                        } catch (Exception e){}
                    }
                    break;
                case TIME:
                    if (!input.matches("(([1][0-2])|([1-9])):[0-5][0-9] (am|pm)")) {
                        valid = false;
                        try {
                            form.addLabel("Err" + i, "Fix Me!", 10 + ((i % 2) * 260), 30 + (i / 2) * 60);
                        } catch (Exception e){}
                    }
                    break;
                case CURRENCY:
                    if (!input.matches("(\\$*)[1-9]([0-9]*)\\.[0-9][0-9]")) {
                        valid = false;
                        try {
                            form.addLabel("Err" + i, "Fix Me!", 10 + ((i % 2) * 260), 30 + (i / 2) * 60);
                        } catch (Exception e){}
                    }
                    break;
                case DECIMAL:
                    if (!input.matches("[0-9][0-9]*\\.[0-9][0-9]*")) {
                        valid = false;
                        try {
                            form.addLabel("Err" + i, "Fix Me!", 10 + ((i % 2) * 260), 30 + (i / 2) * 60);
                        } catch (Exception e){}
                    }
                    break;
                case INTEGER:
                    if (!input.matches("[0-9][0-9]*")) {
                        valid = false;
                        try {
                            form.addLabel("Err" + i, "Fix Me!", 10 + ((i % 2) * 260), 30 + (i / 2) * 60);
                        } catch (Exception e){}
                    }
                    break;
                case PERCENT:
                    if (!input.matches("(([0-9])|([1-9][0-9])|100)%")) {
                        valid = false;
                        try {
                            form.addLabel("Err" + i, "Fix Me!", 10 + ((i % 2) * 260), 30 + (i / 2) * 60);
                        } catch (Exception e){}
                    }
                    break;
                case STRING:
                    if (input.equals("")) {
                        valid = false;
                        try {
                            form.addLabel("Err" + i, "Fix Me!", 10 + ((i % 2) * 260), 30 + (i / 2) * 60);
                        } catch (Exception e){}
                    }
                    break;
            }
        }

        return valid;
    }

    @SuppressWarnings("all")
    private void buildForm ( ) {

        FormField curField;
        FormArea curArea;

        // add fields
        for (int i = 0 ; i < formFields.size() ; i++) {
            curField = formFields.get(i);
            try {form.addTextField(curField.name, curField.label,
                    20, 10 + ((i % 2) * 260), 10 + (i / 2) * 60);} catch (Exception e) {}
        }
        // add areas
        for (int i = 0 ; i < formAreas.size() ; i++) {
            curArea = formAreas.get(i);
            try {form.addTextArea(curArea.name, curArea.label,
                    4, 72, 10, 20 + ((formFields.size()/2) * 80) + i * 110);} catch (Exception e) {}
        }
    }

    private class FormField {

        String name;
        String label;
        Type kind;

        FormField (String name, String label, Type kind) {
            this.kind = kind;
            this.label = label;
            this.name = name;
        }
    }

    private class FormArea {

        String name;
        String label;

        FormArea (String name, String label) {
            this.label = label;
            this.name = name;
        }
    }

}
