/**
 * Matt Laidman
 * 5199807
 *
 * COSC 2P05 - Assignment 2
 * February 29, 2015
 */

import BasicIO.ASCIIDataFile;
import CheckedForm.*;

import java.io.*;
import java.util.LinkedList;
import java.util.Queue;

public class AcmeOrderForm {

    CheckedForm form = new CheckedForm();
    private Queue<Order> orders = new LinkedList<>();

    public AcmeOrderForm ( ) {

        //readQueue();
        buildForm();
        getNewOrders();
        //saveQueue();
    }

    private void getNewOrders ( ) {

        while (form.accept() != 1) {
            Order curOrder = new Order();
            curOrder.date = form.readField("date");
            curOrder.time = form.readField("time");
            curOrder.orderNumber = form.readField("orderNumber");
            curOrder.itemNumber = form.readField("itemNumber");
            curOrder.quantity = form.readField("quantity");
            curOrder.address = form.readText("address");
            orders.add(curOrder);
        }
    }

    @SuppressWarnings("unchecked")
    private void saveQueue ( ) {

        ASCIIDataFile oFile;
        while (true) {
            try {
                oFile = new ASCIIDataFile();
                OutputStream file = new FileOutputStream(oFile.getFile());
                OutputStream buffer = new BufferedOutputStream(file);
                ObjectOutput output = new ObjectOutputStream(buffer);
                output.writeObject(orders);
                output.close();
                buffer.close();
                file.close();
                oFile.close();
            } catch (Exception e) {
                continue;
            }
            return;
        }
    }

    @SuppressWarnings("unchecked")
    private void readQueue ( ) {

        ASCIIDataFile iFile;
        while (true) {
            try {
                iFile = new ASCIIDataFile();
                InputStream file = new FileInputStream(iFile.getFile());
                InputStream buffer = new BufferedInputStream(file);
                ObjectInput input = new ObjectInputStream(buffer);
                orders = (LinkedList<Order>)input.readObject();
                input.close();
                buffer.close();
                file.close();
                iFile.close();
            } catch (Exception e) {
                saveQueue();
                continue;
            }
            return;
        }
    }

    private void buildForm ( ) {

        form.setTitle("Acme Distributing");
        form.addField("date", "Date", Type.DATE);
        form.addField("time", "Time", Type.TIME);
        form.addField("orderNumber", "Order #", Type.INTEGER);
        form.addField("itemNumber", "Item #", Type.INTEGER);
        form.addField("quantity", "Quantity", Type.INTEGER);
        form.addText("address", "Address");
    }


    private class Order implements Serializable {

        String date;
        String time;
        String orderNumber;
        String itemNumber;
        String quantity;
        String address;
    }

    public static void main (String[] args) {new AcmeOrderForm();}
}
